
$('#feed-button').click(function() {
    $('#feed-form').submit();
});


$('#play-button').click(function() {
    $('#play-form').submit();
});


$('#work-button').click(function() {
    $('#work-form').submit();
});


$('#sleep-button').click(function() {
    $('#sleep-form').submit();
});




