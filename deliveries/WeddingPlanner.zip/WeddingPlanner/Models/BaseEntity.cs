namespace WeddingPlanner.Models
{
    public abstract class BaseEntity {}
}
