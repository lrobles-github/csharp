namespace login_reg.Models
{
    public abstract class BaseEntity {}
}
